module csc335.boggle3 {
    requires javafx.controls;
	requires javafx.graphics;
    exports views;
}

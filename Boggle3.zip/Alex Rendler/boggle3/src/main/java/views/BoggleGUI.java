package views;

// Author: Alex Rendler
/*
 * This class implements our previously made boggle class
 * and uses its methods to create a GUI version in which
 * the user is able to start a new game, and end the game
 * with the click of a button. The class takes the users
 * input from the input text field and prints out the results
 * of the game in the results text field.
 */
import java.util.List;
import java.util.Scanner;
import model.Boggle;
import model.DiceTray;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class BoggleGUI extends Application {

	public static void main(String[] args) {

		launch(args);

	}

	private Boggle game;
	private TextArea trayText;
	private TextArea resultText;
	private TextArea inputText;
	private Button newGame;
	private Button endGame;
	private GridPane screen = new GridPane();
	
	// Creates the scene and activates the event handlers
	// for the start and end game buttons.
	public void start(Stage stage) {
		layoutWindow();
		
		// Creates scene and handlers for end/start game
		Scene scene = new Scene(screen, 900, 325);
		EventHandler<ActionEvent> buttonHandler = new AHandler();
		newGame.setOnAction(buttonHandler);
		endGame.setOnAction(buttonHandler);
		stage.setScene(scene);
		stage.show();
		startNewGame();
	}

	// Creates a new diceTray and clears user input 
	private void startNewGame() {
		
		// Gets a new boggle board and clears input
		char[][] tray = new char[4][4];
		DiceTray board = new DiceTray(tray);
		game = new Boggle(board);
		inputText.setText("");
		trayText.setText(game.getBoardAsString());
	}

	// Adds all the buttons, textFields to the scene
	private void layoutWindow() {
		
		// Adds New/End game buttons
		GridPane buttons = new GridPane();
		buttons.setHgap(13);
		buttons.setVgap(10);
		GridPane text = new GridPane();
		newGame = new Button("New Game");
		endGame = new Button("End game");
		text.setHgap(10);
		text.setVgap(1);
		screen.add(text, 1, 2);
		screen.add(buttons, 1, 0);
		buttons.add(endGame, 4, 1);
		buttons.add(newGame, 3, 1);
		
		// Adds the text Enter Attempts to the top
		Label enterAttempts = new Label("Enter Attempts:");
		Label results = new Label("Results:");
		buttons.add(enterAttempts, 8, 1);
		buttons.add(results, 20, 1);
		
		// Adds the diceTray text field uneditable and edits font
		trayText = new TextArea();
		trayText.setEditable(false);
		trayText.setFont(Font.font("Courier New", FontWeight.BOLD, 24));
		text.add(trayText, 1, 4);
		trayText.setMaxWidth(225);
		trayText.setMaxHeight(250);
		
		// Adds blue border to the inputText field
		Rectangle border = new Rectangle();
		border.setWidth(225);
		border.setHeight(276);
		border.setFill(Color.TRANSPARENT);
		border.setStroke(Color.BLUE);
		text.add(border, 2, 4);
		
		// Adds input text field and changes font
		inputText = new TextArea();
		inputText.setFont(Font.font("ChalkBoard", FontWeight.BOLD, 18));
		text.add(inputText, 2, 4);
		inputText.setMaxWidth(225);
		inputText.setWrapText(true);
		
		// Adds result text field, uneditable
		resultText = new TextArea();
		resultText.setEditable(false);
		resultText.setWrapText(true);
		text.add(resultText, 3, 4);
		resultText.setMaxWidth(400);
		resultText.setMaxWidth(400);
	}

	// Determines what to do when End/New game are clicked
	private class AHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			
			// If NewGame button is clicked
			if (event.getSource().equals(newGame)) {
				startNewGame();
				resultText.setText("");
				inputText.setEditable(true);
				
			// If EndGame button is clicked
			} else if (event.getSource().equals(endGame)) {
				inputText.setEditable(false);
				String[] input = inputText.getText().split(" ");
				for (int i = 0; i < input.length; i++) {
					game.guessWord(input[i]);
				}
				
				// Gets the data from Boggle class and enters in result text field
				game.run();
				resultText.setText("Your Score: " + game.score() + "\n\n");
				resultText.appendText("Words you found:\n");
				for (int i = 0; i < game.getCorrect().size(); i++) {
					resultText.appendText(game.getCorrect().get(i) + " ");
					if (i % 15 == 0 && i != 0) {
						resultText.appendText("\n");
					}
				}
				resultText.appendText("\n\n");
				resultText.appendText("Incorrect words:\n");
				List<String> incorrectWords = game.getIncorrect();
				for (int i = 0; i < incorrectWords.size(); i++) {
					resultText.appendText(incorrectWords.get(i) + " ");
					if (i % 15 == 0 && i != 0) {
						resultText.appendText("\n");
					}
				}
				resultText.appendText("\n\n");
				resultText.appendText("You could have found " + game.getMissed().size() + " more words:\n");
				for (int i = 0; i < game.getMissed().size(); i++) {
					resultText.appendText(game.getMissed().get(i) + " ");

				}

			}

		}
	}
}

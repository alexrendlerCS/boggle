package views;


// Programmer: Alex Rendler
/*
 * This program take user input and a file titled
 * BoggleWords.txt to determine if each user input
 * is a valid word in Boggle and proceeds to print out
 * the number of points the player earned, the words
 * they got correct, the words they got incorrect,
 * and all words that could have been made.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import model.Boggle;
import model.DiceTray;

/*
 * This class tracks the correct and incorrect guesses and compares
 * them to the words in BoggleWords.txt to determine the users
 * score, and their correct guesses along with their incorrect 
 * guesses and all possible corect guessses.
 */
public class BoggleConsole {
	private static ArrayList<String> dictionaryWords;
	private static ArrayList<String> guessedWords;
	private static ArrayList<String> incorrectGuesses;

	public static void main(String[] args) {

		System.out.println("Play one game of Boggle");
		System.out.println();
		char[][] board = new char[4][4];
		DiceTray diceTray = new DiceTray(board);
		
		Boggle.printBoard();

		// Load dictionary words from BoggleWords.txt
		dictionaryWords = new ArrayList<>();
		File dictionaryFile = new File("BoggleWords.txt");
		try (Scanner dictionaryScanner = new Scanner(dictionaryFile)) {
			while (dictionaryScanner.hasNextLine()) {
				dictionaryWords.add(dictionaryScanner.nextLine());
			}
		} catch (FileNotFoundException e) {
			System.out.println("Error: Dictionary file not found.");
			System.exit(1);
		}

		// Initializes a list of guessed words and incorrect guesses
		guessedWords = new ArrayList<>();
		incorrectGuesses = new ArrayList<>();

		Scanner inputScanner = new Scanner(System.in);
		System.out.println("Enter words or ZZ to quit:");
		String input = inputScanner.nextLine();
		String[] guesses;

		// Get user input
		while (!input.toUpperCase().equals("ZZ")) {
			guesses = input.split(" ");
			for (String guess : guesses) {
				if (!guess.toUpperCase().equals("ZZ")) {
					// Check to see if the guess is in the dictionary
					if (dictionaryWords.contains(guess)) {
						if (diceTray.found(guess)) {
							if (!guessedWords.contains(guess)) {
								guessedWords.add(guess);
							} else {
								System.out.print("Already guessed this word. Try Again.");
							}
						} else {
							incorrectGuesses.add(guess);
						}
					} else {
						incorrectGuesses.add(guess);
					}
				} else {
					break;
				}
			}
			System.out.println("Enter words or ZZ to quit: ");
			input = inputScanner.nextLine();
		}

		
	}

}

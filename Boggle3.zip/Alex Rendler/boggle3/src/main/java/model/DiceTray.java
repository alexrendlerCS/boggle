package model;


/**
 * Model the tray of dice in the game Boggle. A DiceTray can be constructed with
 * a 4x4 array of characters for testing.
 *
 * A 2nd constructor with no arguments can be added later to simulate the
 * shaking of 16 dice and selection of one side.
 *
 * @author Alex Rendler
 */
import java.util.Random;

public class DiceTray {
	final String[] DICE = { "ELFFDS", "PLANVE", "QUTYWZ", "PTUVSA", "ANAEEP", "IFDKSF", "YLRIDV", "ZNRNHL", "FNMAPL",
			"OBBAOJ", "DOVATG", "IOTMUC", "GPORSJ", "USTENY", "FDJIBV", "LUPETS" };
	final int ROWS = 4;
	final int COLS = 4;
	private static char[][] theBoard;
	final Random random;
	
	public DiceTray(char[][] newBoard) {
		random = new Random();
		theBoard = new char[ROWS][COLS];
		theBoard = newBoard;

		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				int row = i;
				int col = j;
				int side = random.nextInt(6);
				theBoard[row][col] = DICE[j + i].charAt(side);
			}
		}
	}


	public static void printBoard() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				//Check if Q print Qu
				if(theBoard[i][j] == 'Q') {
					System.out.print("Qu");
				}else {
					System.out.print(" " + theBoard[i][j]);
				}
				
			}
			System.out.println();
			System.out.println();
		}
	}

	/**
	 * Return true if attempt can found on the board following the rules of Boggle
	 * like the same letter can only be used once.
	 *
	 * @param attempt A word that may be in the board by connecting consecutive
	 *                letters
	 *
	 * @return True if search is found
	 */
	public boolean found(String attempt) {
		// Case sensitive and length of string check
		attempt = attempt.toUpperCase();
		if (attempt.length() < 3) {
			return false;
		}

		boolean[][] visited = new boolean[4][4];
		// loop through the boggle array to check all starting positions
		for (int row = 0; row < theBoard.length; row++) {
			for (int col = 0; col < theBoard[0].length; col++) {
				if (found(attempt, visited, row, col)) {
					return true;
				}
			}
		}
		return false;
	}

	public boolean found(String attempt, boolean[][] visited, int row, int col) {
		// base case: if the attempt is empty, return true
		if (attempt.length() == 0) {
			return true;
		}
		// base case: if the current position is out of bounds or has been visited,
		// return false
		if (row < 0 || row >= theBoard.length || col < 0 || col >= theBoard[0].length || visited[row][col]) {
			return false;
		}
		// base case: if current position is Q, assume it's followed by 'U'
		if (attempt.charAt(0) == 'Q' && theBoard[row][col] == 'Q') {
			boolean result = found(attempt.substring(1), visited, row - 1, col)
					|| found(attempt.substring(2), visited, row + 1, col)
					|| found(attempt.substring(2), visited, row, col - 1)
					|| found(attempt.substring(2), visited, row, col + 1)
					|| found(attempt.substring(2), visited, row - 1, col - 1)
					|| found(attempt.substring(2), visited, row - 1, col + 1)
					|| found(attempt.substring(2), visited, row + 1, col - 1)
					|| found(attempt.substring(2), visited, row + 1, col + 1);
			visited[row][col] = false;
			return result;
		}
		// check if the current character in the boggle array matches the first
		// character in the attempt
		if (theBoard[row][col] != attempt.charAt(0)) {
			return false;
		}
		// mark the current position as visited
		visited[row][col] = true;
		// recursively check all adjacent positions (up, down, left, right, and
		// diagonals)
		boolean result = found(attempt.substring(1), visited, row - 1, col)
				|| found(attempt.substring(1), visited, row + 1, col)
				|| found(attempt.substring(1), visited, row, col - 1)
				|| found(attempt.substring(1), visited, row, col + 1)
				|| found(attempt.substring(1), visited, row - 1, col - 1)
				|| found(attempt.substring(1), visited, row - 1, col + 1)
				|| found(attempt.substring(1), visited, row + 1, col - 1)
				|| found(attempt.substring(1), visited, row + 1, col + 1);
		// unmark the current position as visited
		visited[row][col] = false;
		return result;
	}
	public void set(int row, int col, char given) {
		theBoard[row][col] = given;
	}
	
	
	public char get(int row, int col) {
		return theBoard[row][col];
	}
	
	public char[][] getArray() {
		return theBoard;
	}


	public int size() {
		int size = 0;
		for(int i=0; i<theBoard.length; i++) {
			size++;
		}
		return size;
	}
	
	
	
	
	
	
}

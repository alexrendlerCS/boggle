package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

// Author: Alex Rendler

/*
 * The boggle class is responsible for keeping track
 * of which user inputed guesses are correct or incorrect,
 * and determining what words the user missed. This class
 * also keeps track of the users score and is in charge
 * of getting the board as a string.
 */

public class Boggle {

	private List<String> guesses;
	private List<String> dictWords;
	private List<String> correctGuesses;
	private List<String> incorrectWords;
	private List<String> allWords;
	private static DiceTray diceTray;

	public Boggle(DiceTray diceTray) {
		
		// Initializes new diceTray and lists to store guesses
		this.diceTray = diceTray;
		guesses = new ArrayList<String>();
		dictWords = new ArrayList<String>();
		correctGuesses = new ArrayList<String>();
		incorrectWords = new ArrayList<String>();
		allWords = new ArrayList<String>();
		
		// Adds words from Boggle.txt to dictWords
		try {
			Scanner scan = new Scanner(new File("BoggleWords.txt"));
			while (scan.hasNext()) {
				dictWords.add(scan.nextLine());}
			scan.close();
		} catch (FileNotFoundException e) {

		}

	}

	public List<String> getCorrect() {
		Collections.sort(correctGuesses);
		return correctGuesses;
	}

	public List<String> getIncorrect() {
		Collections.sort(incorrectWords);
		return incorrectWords;
	}

	public List<String> getMissed() {
		Collections.sort(allWords);
		return allWords;
	}
	
	public static void printBoard() {
		char[][] theBoard = diceTray.getArray();
		for (int i = 0; i < theBoard.length; i++) {
			String finished = "";
			for (int j = 0; j < theBoard.length; j++) {
				if (theBoard[i][j] == 'Q') {
					finished += "Qu ";
				} else {
					finished += theBoard[i][j] + " ";
				}
			}
			System.out.println(finished);
		}
	}

	public String getBoardAsString() {
		char[][] theBoard = diceTray.getArray();
		String finished = "";
		for (int r = 0; r < theBoard.length; r++) {
			finished += "\n";
			for (int c = 0; c < theBoard.length; c++) {
				if (theBoard[r][c] == 'Q')
					finished += " Qu";
				else
					finished += "  " + theBoard[r][c];
			}
			if (r < theBoard.length - 1)
				finished += " \n";
		}
		return finished;
	}

	public void guessWord(String wordGuessed) {
		if (!guesses.contains(wordGuessed)) {
			guesses.add(wordGuessed);
		}
	}
	
	// Checks if inputs are in dictionary and dicetray found method
	// returns to, adds to correctGuesses if successful and incorrect
	// guesses if not.
	public void check() {
		for (int i = 0; i < guesses.size(); i++) {
			String finished = "";
			String word = guesses.get(i);
			if (dictWords.contains(word)) {
				if (diceTray.found(word)) {
					correctGuesses.add(word);
				} else {
					incorrectWords.add(word);
				}
			} else {
				incorrectWords.add(word);
			}
		}

	}

	// Returns the respective score for the correct guesses
	public int score() {
		int score = 0;
		for (int i = 0; i < correctGuesses.size(); i++) {
			String cur = correctGuesses.get(i);
			if (cur.length() == 3 || cur.length() == 4) {
				score += 1;
			}
			if (cur.length() == 5) {
				score += 2;
			}
			if (cur.length() == 6) {
				score += 3;
			}
			if (cur.length() == 7) {
				score += 5;
			}
			if (cur.length() >= 8) {
				score += 11;
			}
		}
		return score;
	}
	
	// Adds every dict word that wasn't found to allWords
	public void allWords() {
		for (int i = 0; i < dictWords.size(); i++) {
			if (!correctGuesses.contains(dictWords.get(i))) {
				if (diceTray.found(dictWords.get(i))) {
					if (!allWords.contains(dictWords.get(i))) {
						allWords.add(dictWords.get(i));
					}
				}
			}
		}
	}

	// Gets all the data needed for BoggleGUI
	public void run() {
		check();
		allWords();
		score();
	}

}
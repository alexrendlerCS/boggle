package tests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

import model.DiceTray;

/**
 * Grader tests for BoggleTray. Just tests word searches. We are not seeking
 * words in a dictionary, just strings for now.
 *
 * @author Alex Rendler
 * @version 1.2
 */

public class DiceTrayTest {

	private char[][] longWords = { { 'A', 'A', 'A', 'A' }, { 'A', 'A', 'A', 'A' }, { 'A', 'A', 'A', 'A' },
			{ 'A', 'A', 'A', 'A' } };

	private DiceTray tray = new DiceTray(longWords);

	@Test
	public void testForSmallStringsNotRealWords() {
		// We are not looking for words in a dictionary now, just strings.
		//
		// searchBoard must return false for strings < length() of 3
		// asserts can take a string argument that prints when the assert fails.
		//
		
		System.out.println(tray.found("QEEN"));
		System.out.println(tray.found("QUEEN"));
		tray.printBoard();
		assertFalse(tray.found(""));
		assertFalse(tray.found("TS"));
		assertFalse(tray.found("ABA"));
		assertFalse(tray.found("TMI"));
		assertTrue(tray.found("aBs")); // Case insensitive
		assertTrue(tray.found("AbS"));
	}

	@Test
	public void testForBiggerStrings() {
		assertTrue(tray.found("sent"));
		assertTrue(tray.found("SENT"));
		assertTrue(tray.found("minded"));
		assertTrue(tray.found("teen"));
		assertTrue(tray.found("dibtd"));
	}

	@Test
	public void testForLongStrings() {
		assertTrue(tray.found("NTMINDED"));
		assertTrue(tray.found("ABSENTMINDEDNESS"));
	}

}

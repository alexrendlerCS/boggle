package tests;


// Programmer: Alex Rendler
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import model.Boggle;
import model.DiceTray;

// 100% Coverage of B0ggle.java
class BoggleTest {

	// Used to get Line 10 "public class Boggle {" covered
	Boggle boggle = new Boggle(null);

	// Compares output of score method to expected outcome
	@Test
	void testScore() {

		// Every length score
		ArrayList<String> guessedWords = new ArrayList<String>();
		guessedWords.add("dog"); // 1
		guessedWords.add("bad"); // 1
		guessedWords.add("head"); // 1
		guessedWords.add("heads"); // 2
		guessedWords.add("domino"); // 3
		guessedWords.add("dominos"); // 4
		guessedWords.add("helicopter"); // 11
		assertEquals(23, Boggle.score(guessedWords));

		// Empty List
		ArrayList<String> anotherWords = new ArrayList<String>();
		assertEquals(0, Boggle.score(anotherWords));

	}

	// Tests to see if the words are printed returns true if no error.
	@Test
	void testPrintBoard() {
		ArrayList<String> guessedWords = new ArrayList<String>();
		guessedWords.add("dog");
		guessedWords.add("bad");
		guessedWords.add("head");
		guessedWords.add("heads");
		guessedWords.add("domino");
		guessedWords.add("dominos");
		guessedWords.add("helicopter");
		Boggle.printWords(guessedWords);
		assertTrue(true);
	}

	// Returns true if all words in dictionary and guessed
	// print out from the given diceTray.
	@Test
	void testPrintAll() {
		ArrayList<String> guessedWords = new ArrayList<String>();
		char[][] board = new char[4][4];
		int score = 0;
		DiceTray diceTray = new DiceTray(board);
		ArrayList<String> dictionaryWords = new ArrayList<String>();
		dictionaryWords.add("AAAA");
		dictionaryWords.add("AAA");
		dictionaryWords.add("BBB");
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				diceTray.set(i, j, 'A');
			}
		}
		for (String word : dictionaryWords) {
			if (diceTray.found(word) == true) {
				score += 1;
			}
		}
		Boggle.printAll(diceTray, dictionaryWords, guessedWords);
		assertEquals(2, score);
	}

	// Tests if lenAll returns accurate len of missed words
	@Test
	void testlenAll() {
		ArrayList<String> guessedWords = new ArrayList<String>();
		char[][] board = new char[4][4];
		int score = 0;
		DiceTray diceTray = new DiceTray(board);
		ArrayList<String> dictionaryWords = new ArrayList<String>();
		dictionaryWords.add("AAAA");
		dictionaryWords.add("AAA");
		dictionaryWords.add("BBB");
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				diceTray.set(i, j, 'A');
			}
		}
		for (String word : dictionaryWords) {
			if (diceTray.found(word) == true) {
				score += 1;
			}
		}
		System.out.println(Boggle.lenAll(diceTray, dictionaryWords, guessedWords));
		assertEquals(2, Boggle.lenAll(diceTray, dictionaryWords, guessedWords));
	}
}
